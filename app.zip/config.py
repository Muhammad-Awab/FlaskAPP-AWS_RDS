# config.py

DB_CONFIG = {
    'user': 'dbadmin123',
    'password': 'dbadmin123',
    'host': 'dbadmin123.cluster-c1fzffy39xml.us-east-1.rds.amazonaws.com',
    'database': 'dbadmin123',
}
